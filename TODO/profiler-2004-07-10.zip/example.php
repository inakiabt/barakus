<?php 
/**
* This file contains a profiler class usage example.
* @filesource
* @package profiler
*/

require_once (dirname (__FILE__) . '/profiler.class.php');
$profiler = new profiler ('test.csv', PROFILE_FILE_TYPE_CSV);
declare (ticks=1);

// Your code goes here!

?>