<?php
// The class !
include_once "../class/GoogleSiteMap.php";
?>